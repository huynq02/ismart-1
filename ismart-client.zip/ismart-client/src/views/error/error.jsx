import React from 'react';


const Error = () => {



    return (
        <>
            <div
                className="access-denied "
            >
                <h1>Không có quyền truy cập vào trang này</h1>
            </div>
        </>
    );
}

export default Error;
